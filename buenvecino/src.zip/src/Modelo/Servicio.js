class Servicio{

}

export default Servicio