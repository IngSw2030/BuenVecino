import React from 'react';
import Banner from './components/Banner';

function Main() {
	return (
		<div>
			<Banner />
		</div>
	);
}

export default Main;
